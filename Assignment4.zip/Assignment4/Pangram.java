
public class Pangram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abcdefghikjklmnopqrstuvwxyz";
		s1=s1.replace(" ","");
		char[] ch1=new char[s1.length()];
		int[] ar=new int[26];
	    boolean flag=false;
		for (int i = 0; i < s1.length(); i++) {
			
		 
			
				  ch1[i] = s1.charAt(i);
			}
		 for (int i = 0; i < ch1.length; i++) {
            
             if (ch1[i] >= 'a' && ch1[i] <= 'z') {
                     ch1[i] = (char) ((int) ch1[i] - 32);
             }
     }
		for (int i = 0; i <= ch1.length-1; i++) {
			
			 
			
			 int index=ch1[i]-65;
			 ar[index]++;
		}
          
		for (int i = 0; i < ar.length; i++) {
			
			 
			if(ar[i]==0) {
				System.out.println("Not Pangram");
				flag=true;
				break;
			}
		}
        if(flag==false) {
        	System.out.println("Pangram");
        }
	}

}
