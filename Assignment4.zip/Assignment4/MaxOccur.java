
public class MaxOccur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="Kalaivani";
		char[] ch=s1.toCharArray();
		int [] count = new int[ch.length];
		boolean flag=true;
		char temp;
		int counter;
		
		for(int i=0;i<ch.length-1;i++) {
			counter=1;
			if(ch[i]!='0') {
			for(int j=i+1;j<ch.length;j++) {
				if(ch[i]==ch[j]) {
					
					counter++;
					ch[j]='0';
				}
				count[i]=counter;
				
			}
		}
		}

		int max = count[0];
	    int ind = 0;

	    for(int i=1; i<count.length; i++) {
	        if (max < count[i]) {
	            ind = i;
	            max = count[i];
	        }
	    }
	    System.out.println(" Character " + ch[ind] + " has occured " + max + " times in the string");


	}

}
