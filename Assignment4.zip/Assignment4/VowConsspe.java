
public class VowConsspe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello ! How are you doing?";
		char[] c=str.toCharArray();
		int vowels = 0;
		int consonant = 0;
		int specialChar = 0;
		for(int i=0;i<c.length;i++) {
			 char ch = c[i];
			if ( (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ) {
				
				if (ch == 'a' || ch == 'e' || ch == 'i' ||
		                ch == 'o' || ch == 'u')
		                vowels++;
		            else
		                consonant++;
			}
		
		if ((ch >= 32 && ch <= 47) || (ch >= 58 && ch <= 64)|| (ch >= 91 && ch<= 96) || (ch>= 123 && ch <= 126)){
			specialChar++;
		}
		

	}
		System.out.println("Vowels:" +  vowels + " Consonants" + ":"+ consonant + " SpecialCharacters:"+ specialChar);

}
}
