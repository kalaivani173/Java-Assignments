
public class PrintDups {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str= "Kalaivani";
		StringBuilder sb=new StringBuilder();
		char[] c1=str.toCharArray();
		boolean flag;
		for(int i=0;i<str.length();i++) {
			flag=false;
			for(int j=i+1;j<str.length();j++) {
				if(c1[i]==c1[j]) {
				
					flag=true;
					c1[j]='0';
					 
				}
			}
			if(flag==true && c1[i]!='0') {
				sb.append(c1[i]);
			}
			
				}
				
			
		System.out.print(sb);
		}
	


}
