
public class UniqueStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="asdfg";
		char[] ch=s1.toCharArray();
		boolean flag=true;
		for(int i=0;i<ch.length-1;i++) {
			for(int j=i+1;j<ch.length;j++) {
				if(ch[i]==ch[j]) {
					flag=false;
				}
			}
		}
		if(flag==true) {
			System.out.println("String has all unique characters");
		}
		else {
			System.out.println("String does not have all unique characters");
		}

	}

}
