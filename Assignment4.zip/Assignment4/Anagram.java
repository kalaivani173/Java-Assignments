import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="Ra e";
		String s2="Ca e";
		s1=s1.replace(" ","");
		s2=s2.replace(" ","");
		//Converting String to Character Array
		char[] ch1=new char[s1.length()];
		char[] ch2=new char[s2.length()];
		for (int i = 0; i < s1.length(); i++) {
			
		 {
			
				  ch1[i] = s1.charAt(i);
			}
          
        }
		for (int i = 0; i < s2.length(); i++) {
			
			
		 {
		

            ch2[i] = s2.charAt(i);
        
		}
		}
    
		
		//Converting to Lower case
		for(int i1=0;i1<ch1.length;i1++) {
		if(ch1[i1]>=65 && ch1[i1]<=90)
	      {
			ch1[i1]= (char) (ch1[i1]+32);
	      }
		}
		for(int i1=0;i1<ch2.length;i1++) {
			if(ch2[i1]>=65 && ch2[i1]<=90)
		      {
				ch2[i1] = (char) (ch2[i1] +32);
		      }
			}
	

            for(int i1=0;i1<ch1.length;i1++) {
			
			for(int j=1;j<ch1.length;j++) {
				
				if(ch1[j]<ch1[j-1]) {
					char temp=ch1[j];
					ch1[j]=ch1[j-1];
					ch1[j-1]=temp;
				}
			}
            }
            for(int i1=0;i1<ch2.length;i1++) {
    			
    			for(int j=1;j<ch2.length;j++) {
    				
    				if(ch2[j]<ch2[j-1]) {
    					char temp=ch2[j];
    					ch2[j]=ch2[j-1];
    					ch2[j-1]=temp;
    				}
    			}
                }
            
 
	if(Arrays.equals(ch1,ch2)) {
			System.out.println("Anagram");
		}
		else
		{
			System.out.println("Not Anagram");
		}
		
		

	}
	}


