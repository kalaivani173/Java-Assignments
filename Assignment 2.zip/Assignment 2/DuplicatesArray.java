import java.util.*;
public class DuplicatesArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements");
		int num=sc.nextInt();
		System.out.println("Enter the elements");
		int[] arr=new int[num];
		for(int i=0;i<num;i++) {
			
			arr[i]=sc.nextInt();
		}
		
	boolean flag=false;
	for(int i=0;i<num;i++) {
		
		for(int j=i+1;j<num;j++) {
			
			if(arr[i]==arr[j]) {
				System.out.println("Found Duplicate :" + " " + "Number " + arr[j] + " "+"at" + " " + i+ " " + j + " locations");
				flag=true;
			}
		}
	}
	if(flag==false) {
		System.out.println("Duplicates not found");
	}
		

	}

}
