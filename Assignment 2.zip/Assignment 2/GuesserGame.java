import java.util.Scanner;
public class GuesserGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Umpire u=new Umpire();
         u.collectwordFromGuesser();
         u.collectwordFromPlayer();
         u.compare();
	}

}
class Guesser
{
    String gword;
    String guessingword()
    {
        System.out.println("Please guess a word Guesser!");
        Scanner scan=new Scanner(System.in);
        gword=scan.next();
        return gword;
    }
}
class Player
{
    String pword;
    String predictingWord()
    {
        System.out.println("Please predict a word Players!");
        Scanner scan=new Scanner(System.in);
        pword=scan.next();
        return pword;
          }
}
class Umpire
{
    String wordFromGuesser;
    String wordFromPlayer1;
    String wordFromPlayer2;
    String wordFromPlayer3;
    void collectwordFromGuesser()
    {
        Guesser g=new Guesser();
        wordFromGuesser=g.guessingword();
    }
    void collectwordFromPlayer()
    {
     Player p1=new Player();
     Player p2=new Player();
     Player p3=new Player();
     wordFromPlayer1=p1.predictingWord();
     wordFromPlayer2=p1.predictingWord();
     wordFromPlayer3=p1.predictingWord();
    }
    void compare()
    {
        if(wordFromPlayer1.equals(wordFromGuesser))
        {
            System.out.println("player1 has won the game");
        }
        else if (wordFromPlayer2.equals(wordFromGuesser))
        {
             System.out.println("player2 has won the game");
        }
        else if (wordFromPlayer3.equals(wordFromGuesser))
        {
             System.out.println("player3 has won the game");
        }
        else
        {
            System.out.println("game lost,try again");
        }
    }
}