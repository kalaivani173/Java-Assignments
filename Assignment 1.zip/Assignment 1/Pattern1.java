
public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		
		//I
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(i==0 || i==n-1 || j==(n-1)/2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
		
		System.out.println(" ");
		//N
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(i==j || j==0 || j==n-1)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
		System.out.println(" ");
		//E
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(i==0 || j==0 || i==n-1 || i==(n-1)/2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
		System.out.println(" ");
		//U
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(i==n-1 && j>0 && j< n-1|| j==0 && i<=3*n/4 || j==n-1 && i<=3*n/4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
		System.out.println(" ");
		//R
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(j == (n-1)&& i>(n-1)/2|| j==0 || i==0 && j<=3*n/4 || i==(n-1)/2 && j<=3*n/4 || j==(n-1) && i>0 && i<(n-1)/2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
		System.out.println(" ");
		//O
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if((j==0 && i >= n/4 && i<=3*n/4) || (j==n-1 && i >= n/4 && i<=3*n/4) || (i==n-1 && j>0 && j< n-1) || (i==0 && j>0 && j< n-1 ))
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}
		System.out.println(" ");
		
		//N
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(i==j || j==0 || j==n-1)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println(" ");
		}

	}
	

}
